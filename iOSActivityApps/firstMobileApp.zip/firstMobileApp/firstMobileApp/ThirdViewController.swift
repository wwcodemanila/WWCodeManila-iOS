//
//  ThirdViewController.swift
//  firstMobileApp
//
//  Created by Ma. Ciela Salazar on 8/21/17.
//  Copyright © 2017 Ciela Salazar. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
